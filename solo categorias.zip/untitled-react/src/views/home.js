import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <div className="home-home">
    
        <div className="filtros-basicos-div">
          <div className="filtro-basicos">
            <button className="home-button-primero">
              <span className="home-text-primero">
                <span>Todo</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>India</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Italiana</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Asiatica</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>China</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Frutas</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Vegetales</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Vegano</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario ">
                <span>Vegetariano</span>
              </span>
            </button>
            <button className="home-button-secundario">
              <span className="home-text-secundario">
                <span>Celiaco</span>
              </span>
            </button>
          </div>
        </div>


        <div className="home-platos">
          <div className="home-cards">
            <div>
              <div className="home-food-photo">
                <img
                  src="/external/imagei044-n2p-200w.png"
                  alt="ImageI044"
                  className="home-image"
                />
                <div className="home-bookmark">
                  <div className="home-icon-nav-bookmark-inactive">
                    <img
                      src="/external/unioni044-vu8.svg"
                      alt="UnionI044"
                      className="home-union"
                    />
                  </div>
                  <div className="home-frame">
                    <div className="home-icon-nav-bookmark-inactive01">
                      <img
                        src="/external/unioni044-0iji.svg"
                        alt="UnionI044"
                        className="home-union1"
                      />
                    </div>
                  </div>
                </div>
                <div className="home-title-button">
                  <span className="home-text022">
                    <span>Ensalada César</span>
                  </span>
                </div>
                <div className="home-image01">
                  <img
                    src="/external/ellipse1i044-g4zq-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse1"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-n17k-200w.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview"
                  />
                </div>
              </div>
              <div className="home-rating">
                <img
                  src="/external/stari044-ywj.svg"
                  alt="starI044"
                  className="home-star"
                />
                <span className="home-text024 TextStyleSmallerTextRegular">
                  <span>4.5</span>
                </span>
              </div>
              <div className="home-time">
                <div className="home-time01">
                  <span className="home-text026 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text030 TextStyleSmallerTextBold">
                    <span>50 Mins</span>
                  </span>
                </div>
                <div className="home-time02">
                  <span className="home-text032 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text036 TextStyleSmallerTextBold">
                    <span>2500$</span>
                  </span>
                </div>
                <div className="home-time03">
                  <div className="home-time04">
                    <span className="home-text038 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text040 TextStyleSmallerTextBold">
                      <span>1500 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="home-card21">
              <div className="home-food-photo1">
                <img
                  src="/external/imagei044-547q-200w.png"
                  alt="ImageI044"
                  className="home-image02"
                />
                <div className="home-bookmark1">
                  <div className="home-icon-nav-bookmark-inactive02">
                    <img
                      src="/external/unioni044-p9l.svg"
                      alt="UnionI044"
                      className="home-union2"
                    />
                  </div>
                  <div className="home-frame01">
                    <div className="home-icon-nav-bookmark-inactive03">
                      <img
                        src="/external/unioni044-8zs.svg"
                        alt="UnionI044"
                        className="home-union3"
                      />
                    </div>
                  </div>
                </div>
                <div className="home-title-button01">
                  <span className="home-text042">
                    <span>Ensalada Griega</span>
                  </span>
                </div>
                <div className="home-image03">
                  <img
                    src="/external/ellipse1i044-ezxt-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse101"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-uty9o-200w.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview1"
                  />
                </div>
              </div>
              <div className="home-rating01">
                <img
                  src="/external/stari044-xrwp.svg"
                  alt="starI044"
                  className="home-star01"
                />
                <span className="home-text044 TextStyleSmallerTextRegular">
                  <span>3.5</span>
                </span>
              </div>
              <div className="home-time05">
                <div className="home-time06">
                  <span className="home-text046 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text050 TextStyleSmallerTextBold">
                    <span>15 Mins</span>
                  </span>
                </div>
                <div className="home-time07">
                  <span className="home-text052 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text056 TextStyleSmallerTextBold">
                    <span>3000$</span>
                  </span>
                </div>
                <div className="home-time08">
                  <div className="home-time09">
                    <span className="home-text058 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text060 TextStyleSmallerTextBold">
                      <span>1000 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="home-card22">
              <div className="home-food-photo2">
                <img
                  src="/external/imagei044-q7en-200w.png"
                  alt="ImageI044"
                  className="home-image04"
                />
                <div className="home-bookmark2">
                  <div className="home-icon-nav-bookmark-inactive04"></div>
                  <div className="home-frame02">
                    <div className="home-icon-nav-bookmark-inactive05"></div>
                  </div>
                </div>
                <div className="home-title-button02">
                  <span className="home-text062">
                    <span>Ensañada terishaki</span>
                  </span>
                </div>
                <div className="home-image05">
                  <img
                    src="/external/ellipse1i044-sgmn-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse102"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-j59-200w.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview2"
                  />
                </div>
              </div>
              <div className="home-rating02">
                <span className="home-text064 TextStyleSmallerTextRegular">
                  <span>5.0</span>
                </span>
              </div>
              <div className="home-time10">
                <div className="home-time11">
                  <span className="home-text066 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text070 TextStyleSmallerTextBold">
                    <span>10 Mins</span>
                  </span>
                </div>
                <div className="home-time12">
                  <span className="home-text072 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text076 TextStyleSmallerTextBold">
                    <span>1750$</span>
                  </span>
                </div>
                <div className="home-time13">
                  <div className="home-time14">
                    <span className="home-text078 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text080 TextStyleSmallerTextBold">
                      <span>750 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="home-food-photo3">
                <img
                  src="/external/imagei044-nvkc-200h.png"
                  alt="ImageI044"
                  className="home-image06"
                />
                <div className="home-bookmark3">
                  <div className="home-icon-nav-bookmark-inactive06"></div>
                  <div className="home-frame03">
                    <div className="home-icon-nav-bookmark-inactive07"></div>
                  </div>
                </div>
                <div className="home-title-button03">
                  <span className="home-text082">
                    <span>Ensalada César</span>
                  </span>
                </div>
                <div className="home-image07">
                  <img
                    src="/external/ellipse1i044-h6dj-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse103"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-suy-200h.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview3"
                  />
                </div>
              </div>
              <div className="home-rating03">
                <span className="home-text084 TextStyleSmallerTextRegular">
                  <span>4.5</span>
                </span>
              </div>
              <div className="home-time15">
                <div className="home-time16">
                  <span className="home-text086 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text090 TextStyleSmallerTextBold">
                    <span>50 Mins</span>
                  </span>
                </div>
                <div className="home-time17">
                  <span className="home-text092 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text096 TextStyleSmallerTextBold">
                    <span>2500$</span>
                  </span>
                </div>
                <div className="home-time18">
                  <div className="home-time19">
                    <span className="home-text098 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text100 TextStyleSmallerTextBold">
                      <span>1500 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="home-food-photo4">
                <img
                  src="/external/imagei044-i9bp-200h.png"
                  alt="ImageI044"
                  className="home-image08"
                />
                <div className="home-bookmark4">
                  <div className="home-icon-nav-bookmark-inactive08"></div>
                  <div className="home-frame04">
                    <div className="home-icon-nav-bookmark-inactive09"></div>
                  </div>
                </div>
                <div className="home-title-button04">
                  <span className="home-text102">
                    <span>Ensalada Griega</span>
                  </span>
                </div>
                <div className="home-image09">
                  <img
                    src="/external/ellipse1i044-1h8o-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse104"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-jzqu-200h.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview4"
                  />
                </div>
              </div>
              <div className="home-rating04">
                <span className="home-text104 TextStyleSmallerTextRegular">
                  <span>3.5</span>
                </span>
              </div>
              <div className="home-time20">
                <div className="home-time21">
                  <span className="home-text106 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text110 TextStyleSmallerTextBold">
                    <span>15 Mins</span>
                  </span>
                </div>
                <div className="home-time22">
                  <span className="home-text112 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text116 TextStyleSmallerTextBold">
                    <span>3000$</span>
                  </span>
                </div>
                <div className="home-time23">
                  <div className="home-time24">
                    <span className="home-text118 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text120 TextStyleSmallerTextBold">
                      <span>1000 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="home-food-photo5">
                <img
                  src="/external/imagei044-ccb-200h.png"
                  alt="ImageI044"
                  className="home-image10"
                />
                <div className="home-bookmark5">
                  <div className="home-icon-nav-bookmark-inactive10"></div>
                  <div className="home-frame05">
                    <div className="home-icon-nav-bookmark-inactive11"></div>
                  </div>
                </div>
                <div className="home-title-button05">
                  <span className="home-text122">
                    <span>Ensañada terishaki</span>
                  </span>
                </div>
                <div className="home-image11">
                  <img
                    src="/external/ellipse1i044-jx2zd-200h.png"
                    alt="Ellipse1I044"
                    className="home-ellipse105"
                  />
                  <img
                    src="/external/monikagrabkowskapcxjvsesb5aunsplashremovebgpreviewi044-eyoq-200h.png"
                    alt="monikagrabkowskapCxJvSeSB5AunsplashremovebgpreviewI044"
                    className="home-monikagrabkowskap-cx-jv-se-sb5-aunsplashremovebgpreview5"
                  />
                </div>
              </div>
              <div className="home-rating05">
                <span className="home-text124 TextStyleSmallerTextRegular">
                  <span>5.0</span>
                </span>
              </div>
              <div className="home-time25">
                <div className="home-time26">
                  <span className="home-text126 TextStyleSmallerTextRegular">
                    <span>Tiempo</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text130 TextStyleSmallerTextBold">
                    <span>10 Mins</span>
                  </span>
                </div>
                <div className="home-time27">
                  <span className="home-text132 TextStyleSmallerTextRegular">
                    <span>Precio</span>
                    <br></br>
                    <span></span>
                  </span>
                  <span className="home-text136 TextStyleSmallerTextBold">
                    <span>1750$</span>
                  </span>
                </div>
                <div className="home-time28">
                  <div className="home-time29">
                    <span className="home-text138 TextStyleSmallerTextRegular">
                      <span>Calorías</span>
                    </span>
                    <span className="home-text140 TextStyleSmallerTextBold">
                      <span>750 Kcal</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <span className="home-text142 TextStyleNormalTextBold">
          <span>Novedades</span>
        </span>
        <div className="home-frame3">
          <div className="home-cards-new-recipes">
            <div className="home-component81">
              <div className="home-card">
                <img
                  src="/external/rectangle643i045-sd5-200h.png"
                  alt="Rectangle643I045"
                  className="home-rectangle643"
                />
                <div className="home-rating06">
                  <img
                    src="/external/stari045-crz.svg"
                    alt="starI045"
                    className="home-star02"
                  />
                  <img
                    src="/external/stari045-uw5tk.svg"
                    alt="starI045"
                    className="home-star03"
                  />
                  <img
                    src="/external/stari045-ybx7o.svg"
                    alt="starI045"
                    className="home-star04"
                  />
                  <img
                    src="/external/stari045-o1ah.svg"
                    alt="starI045"
                    className="home-star05"
                  />
                  <img
                    src="/external/stari045-yxep.svg"
                    alt="starI045"
                    className="home-star06"
                  />
                </div>
                <div className="home-image12">
                  <img
                    src="/external/ellipse1i045-h2am-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse106"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-4ev-200w.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash1"
                  />
                </div>
                <div className="home-title-button06">
                  <span className="home-text144 TextStyleSmallTextBold">
                    <span>Mac and cheese</span>
                  </span>
                </div>
                <div className="home-creator">
                  <img
                    src="/external/unsplashij24uq1smwmi045-s7g7-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m"
                  />
                  <span className="home-text146 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time30">
                <div className="home-vuesaxoutlinetimer">
                  <div className="home-vuesaxoutlinetimer01">
                    <div className="home-timer">
                      <img
                        src="/external/vectori045-j1ce.svg"
                        alt="VectorI045"
                        className="home-vector"
                      />
                      <img
                        src="/external/vectori045-qzx.svg"
                        alt="VectorI045"
                        className="home-vector01"
                      />
                      <img
                        src="/external/vectori045-ke04.svg"
                        alt="VectorI045"
                        className="home-vector02"
                      />
                    </div>
                  </div>
                </div>
                <span className="home-text148 TextStyleSmallerTextRegular">
                  <span>20 mins</span>
                </span>
              </div>
              <div className="home-precio">
                <img
                  src="/external/ionpricetagoutlinei045-gfvj.svg"
                  alt="ionpricetagoutlineI045"
                  className="home-ionpricetagoutline"
                />
                <span className="home-text150 TextStyleSmallerTextRegular">
                  <span>3000$</span>
                </span>
              </div>
              <div className="home-kcal">
                <div className="home-component79">
                  <div className="home-rectangle647">
                    <img
                      src="/external/rectangle647i045-ce3i-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64701"
                    />
                  </div>
                  <div className="home-group146">
                    <img
                      src="/external/vectori045-v7o.svg"
                      alt="VectorI045"
                      className="home-vector03"
                    />
                  </div>
                </div>
                <span className="home-text152 TextStyleSmallerTextRegular">
                  <span>1000 Kcal</span>
                </span>
              </div>
              <div className="home-frame06">
                <img
                  src="/external/rectangle2i045-uija-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle2"
                />
                <div className="home-icon-nav-bookmark-inactive12">
                  <img
                    src="/external/unioni045-9ln.svg"
                    alt="UnionI045"
                    className="home-union4"
                  />
                </div>
              </div>
            </div>
            <div className="home-component811">
              <div className="home-card1">
                <img
                  src="/external/rectangle643i045-ggvr-300w.png"
                  alt="Rectangle643I045"
                  className="home-rectangle6431"
                />
                <div className="home-rating07">
                  <img
                    src="/external/stari045-ym5.svg"
                    alt="starI045"
                    className="home-star07"
                  />
                  <img
                    src="/external/stari045-c14.svg"
                    alt="starI045"
                    className="home-star08"
                  />
                  <img
                    src="/external/stari045-65wk.svg"
                    alt="starI045"
                    className="home-star09"
                  />
                  <img
                    src="/external/stari045-eqx9.svg"
                    alt="starI045"
                    className="home-star10"
                  />
                  <img
                    src="/external/stari045-6c5r.svg"
                    alt="starI045"
                    className="home-star11"
                  />
                </div>
                <div className="home-image13">
                  <img
                    src="/external/ellipse1i045-zada-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse107"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-tw19-200h.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash11"
                  />
                </div>
                <div className="home-title-button07">
                  <span className="home-text154 TextStyleSmallTextBold">
                    <span>Budín de pan</span>
                  </span>
                </div>
                <div className="home-creator1">
                  <img
                    src="/external/unsplashij24uq1smwmi045-iudw-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m1"
                  />
                  <span className="home-text156 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time31">
                <div className="home-vuesaxoutlinetimer02">
                  <div className="home-vuesaxoutlinetimer03">
                    <div className="home-timer1">
                      <img
                        src="/external/vectori045-bbl.svg"
                        alt="VectorI045"
                        className="home-vector04"
                      />
                      <img
                        src="/external/vectori045-ctty.svg"
                        alt="VectorI045"
                        className="home-vector05"
                      />
                      <img
                        src="/external/vectori045-8up.svg"
                        alt="VectorI045"
                        className="home-vector06"
                      />
                    </div>
                  </div>
                </div>
                <span className="home-text158 TextStyleSmallerTextRegular">
                  <span>30 mins</span>
                </span>
              </div>
              <div className="home-precio1">
                <span className="home-text160 TextStyleSmallerTextRegular">
                  <span>6000$</span>
                </span>
              </div>
              <div className="home-kcal1">
                <div className="home-component791">
                  <div className="home-rectangle64702">
                    <img
                      src="/external/rectangle647i045-8g6-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64703"
                    />
                  </div>
                  <div className="home-group1461">
                    <img
                      src="/external/vectori045-wvo.svg"
                      alt="VectorI045"
                      className="home-vector07"
                    />
                  </div>
                </div>
                <span className="home-text162 TextStyleSmallerTextRegular">
                  <span>5000 Kcal</span>
                </span>
              </div>
              <div className="home-frame07">
                <img
                  src="/external/rectangle2i045-ca4-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle21"
                />
                <div className="home-icon-nav-bookmark-inactive13"></div>
              </div>
            </div>
            <div className="home-component82">
              <div className="home-card2 home-card2">
                <img
                  src="/external/rectangle643i045-1irj-300w.png"
                  alt="Rectangle643I045"
                  className="home-rectangle6432"
                />
                <div className="home-rating08"></div>
                <div className="home-image14">
                  <img
                    src="/external/ellipse1i045-hj9a-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse108"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-h2a-200h.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash12"
                  />
                </div>
                <div className="home-title-button08">
                  <span className="home-text164 TextStyleSmallTextBold">
                    <span>Mac and cheese</span>
                  </span>
                </div>
                <div className="home-creator2">
                  <img
                    src="/external/unsplashij24uq1smwmi045-zvwj-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m2"
                  />
                  <span className="home-text166 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time32">
                <div className="home-vuesaxoutlinetimer04">
                  <div className="home-vuesaxoutlinetimer05">
                    <div className="home-timer2"></div>
                  </div>
                </div>
                <span className="home-text168 TextStyleSmallerTextRegular">
                  <span>20 mins</span>
                </span>
              </div>
              <div className="home-precio2">
                <span className="home-text170 TextStyleSmallerTextRegular">
                  <span>3000$</span>
                </span>
              </div>
              <div className="home-kcal2">
                <div className="home-component792">
                  <div className="home-rectangle64704">
                    <img
                      src="/external/rectangle647i045-w2do-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64705"
                    />
                  </div>
                  <div className="home-group1462"></div>
                </div>
                <span className="home-text172 TextStyleSmallerTextRegular">
                  <span>1000 Kcal</span>
                </span>
              </div>
              <div className="home-frame08">
                <img
                  src="/external/rectangle2i045-gqpa-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle22"
                />
                <div className="home-icon-nav-bookmark-inactive14"></div>
              </div>
            </div>
            <div className="home-component83">
              <div className="home-card3 home-card3">
                <img
                  src="/external/rectangle643i045-ojva-300w.png"
                  alt="Rectangle643I045"
                  className="home-rectangle6433"
                />
                <div className="home-rating09"></div>
                <div className="home-image15">
                  <img
                    src="/external/ellipse1i045-tftl-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse109"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-prth-200h.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash13"
                  />
                </div>
                <div className="home-title-button09">
                  <span className="home-text174 TextStyleSmallTextBold">
                    <span>Budín de pan</span>
                  </span>
                </div>
                <div className="home-creator3">
                  <img
                    src="/external/unsplashij24uq1smwmi045-cirk-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m3"
                  />
                  <span className="home-text176 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time33">
                <div className="home-vuesaxoutlinetimer06">
                  <div className="home-vuesaxoutlinetimer07">
                    <div className="home-timer3"></div>
                  </div>
                </div>
                <span className="home-text178 TextStyleSmallerTextRegular">
                  <span>30 mins</span>
                </span>
              </div>
              <div className="home-precio3">
                <span className="home-text180 TextStyleSmallerTextRegular">
                  <span>6000$</span>
                </span>
              </div>
              <div className="home-kcal3">
                <div className="home-component793">
                  <div className="home-rectangle64706">
                    <img
                      src="/external/rectangle647i045-cblb-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64707"
                    />
                  </div>
                  <div className="home-group1463"></div>
                </div>
                <span className="home-text182 TextStyleSmallerTextRegular">
                  <span>5000 Kcal</span>
                </span>
              </div>
              <div className="home-frame09">
                <img
                  src="/external/rectangle2i045-pb9j-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle23"
                />
                <div className="home-icon-nav-bookmark-inactive15"></div>
              </div>
            </div>
            <div className="home-component84">
              <div className="home-card4 home-card4">
                <img
                  src="/external/rectangle643i045-4jku-300w.png"
                  alt="Rectangle643I045"
                  className="home-rectangle6434"
                />
                <div className="home-rating10"></div>
                <div className="home-image16">
                  <img
                    src="/external/ellipse1i045-kf56-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse110"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-b9y7-200h.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash14"
                  />
                </div>
                <div className="home-title-button10">
                  <span className="home-text184 TextStyleSmallTextBold">
                    <span>Mac and cheese</span>
                  </span>
                </div>
                <div className="home-creator4">
                  <img
                    src="/external/unsplashij24uq1smwmi045-3i9-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m4"
                  />
                  <span className="home-text186 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time34">
                <div className="home-vuesaxoutlinetimer08">
                  <div className="home-vuesaxoutlinetimer09">
                    <div className="home-timer4"></div>
                  </div>
                </div>
                <span className="home-text188 TextStyleSmallerTextRegular">
                  <span>20 mins</span>
                </span>
              </div>
              <div className="home-precio4">
                <span className="home-text190 TextStyleSmallerTextRegular">
                  <span>3000$</span>
                </span>
              </div>
              <div className="home-kcal4">
                <div className="home-component794">
                  <div className="home-rectangle64708">
                    <img
                      src="/external/rectangle647i045-3n1f-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64709"
                    />
                  </div>
                  <div className="home-group1464"></div>
                </div>
                <span className="home-text192 TextStyleSmallerTextRegular">
                  <span>1000 Kcal</span>
                </span>
              </div>
              <div className="home-frame10">
                <img
                  src="/external/rectangle2i045-m6ht-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle24"
                />
                <div className="home-icon-nav-bookmark-inactive16"></div>
              </div>
            </div>
            <div className="home-component85">
              <div className="home-card5 home-card5">
                <img
                  src="/external/rectangle643i045-47h7-300w.png"
                  alt="Rectangle643I045"
                  className="home-rectangle6435"
                />
                <div className="home-rating11"></div>
                <div className="home-image17">
                  <img
                    src="/external/ellipse1i045-gii-200h.png"
                    alt="Ellipse1I045"
                    className="home-ellipse111"
                  />
                  <img
                    src="/external/maemuh5hj8qv2tx4unsplash1i045-gkyh-200h.png"
                    alt="maemuH5Hj8QV2Tx4unsplash1I045"
                    className="home-maemu-h5-hj8qv2-tx4unsplash15"
                  />
                </div>
                <div className="home-title-button11">
                  <span className="home-text194 TextStyleSmallTextBold">
                    <span>Budín de pan</span>
                  </span>
                </div>
                <div className="home-creator5">
                  <img
                    src="/external/unsplashij24uq1smwmi045-dbvj-200h.png"
                    alt="unsplashIj24Uq1sMwMI045"
                    className="home-unsplash-ij24-uq1s-mw-m5"
                  />
                  <span className="home-text196 TextStyleSmallerTextRegular">
                    <span>De Tomás Neimerman</span>
                  </span>
                </div>
              </div>
              <div className="home-time35">
                <div className="home-vuesaxoutlinetimer10">
                  <div className="home-vuesaxoutlinetimer11">
                    <div className="home-timer5"></div>
                  </div>
                </div>
                <span className="home-text198 TextStyleSmallerTextRegular">
                  <span>30 mins</span>
                </span>
              </div>
              <div className="home-precio5">
                <span className="home-text200 TextStyleSmallerTextRegular">
                  <span>6000$</span>
                </span>
              </div>
              <div className="home-kcal5">
                <div className="home-component795">
                  <div className="home-rectangle64710">
                    <img
                      src="/external/rectangle647i045-u9wf-200h.png"
                      alt="Rectangle647I045"
                      className="home-rectangle64711"
                    />
                  </div>
                  <div className="home-group1465"></div>
                </div>
                <span className="home-text202 TextStyleSmallerTextRegular">
                  <span>5000 Kcal</span>
                </span>
              </div>
              <div className="home-frame11">
                <img
                  src="/external/rectangle2i045-bo9t-200h.png"
                  alt="Rectangle2I045"
                  className="home-rectangle25"
                />
                <div className="home-icon-nav-bookmark-inactive17"></div>
              </div>
            </div>
          </div>
        </div>
        <img
          src="/external/rectangle380457-ejjp-200h.png"
          alt="Rectangle380457"
          className="home-rectangle38"
        />
        <div className="home-vuesaxoutlinesetting4">
          <div className="home-vuesaxoutlinesetting41">
            <div className="home-setting4">
              <img
                src="/external/vectori045-62x.svg"
                alt="VectorI045"
                className="home-vector08"
              />
              <img
                src="/external/vectori045-4xnh.svg"
                alt="VectorI045"
                className="home-vector09"
              />
              <img
                src="/external/vectori045-m5di.svg"
                alt="VectorI045"
                className="home-vector10"
              />
              <img
                src="/external/vectori045-iwbd4.svg"
                alt="VectorI045"
                className="home-vector11"
              />
              <img
                src="/external/vectori045-usf.svg"
                alt="VectorI045"
                className="home-vector12"
              />
              <img
                src="/external/vectori045-vie6.svg"
                alt="VectorI045"
                className="home-vector13"
              />
            </div>
          </div>
        </div>
        <div className="home-search">
          <img
            src="/external/rectangle60460-cbyk-200h.png"
            alt="Rectangle60460"
            className="home-rectangle6"
          />
          <div className="home-vuesaxoutlinesearchnormal">
            <div className="home-vuesaxoutlinesearchnormal1">
              <div className="home-searchnormal">
                <img
                  src="/external/vectori046-ocnn.svg"
                  alt="VectorI046"
                  className="home-vector14"
                />
                <img
                  src="/external/vectori046-uvu.svg"
                  alt="VectorI046"
                  className="home-vector15"
                />
              </div>
            </div>
          </div>
          <span className="home-text204 TextStyleSmallerTextRegular">
            <span>Busca una receta</span>
          </span>
        </div>
        <div className="home-titttle">
          <span className="home-text206 TextStyleLargeTextBold">
            <span>Hola Santiago!</span>
          </span>
          <span className="home-text208 TextStyleSmallerTextRegular">
            <span>Que vas a cocinar hoy?</span>
          </span>
        </div>
        <div className="home-component15">
          <div className="home-component11">
            <img
              src="/external/rectangle292i046-s2zd-200h.png"
              alt="Rectangle292I046"
              className="home-rectangle292"
            />
            <img
              src="/external/rectangle293i046-1xrr-200h.png"
              alt="Rectangle293I046"
              className="home-rectangle293"
            />
            <img
              src="/external/favtiendai046-6j1.svg"
              alt="favtiendaI046"
              className="home-favtienda"
            />
            <img
              src="/external/busquedaiconi046-4fcn.svg"
              alt="busquedaiconI046"
              className="home-busquedaicon"
            />
            <img
              src="/external/perfiliconi046-w1jp.svg"
              alt="perfiliconI046"
              className="home-perfilicon"
            />
            <span className="home-text210">
              <span>Favoritos</span>
            </span>
            <span className="home-text212">
              <span>Buscar</span>
            </span>
            <span className="home-text214">
              <span>Cesta</span>
            </span>
            <span className="home-text216">
              <span>Perfil</span>
            </span>
            <div className="home-icon-nav-bookmark-inactive18">
              <img
                src="/external/unioni046-cwu.svg"
                alt="UnionI046"
                className="home-union5"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
